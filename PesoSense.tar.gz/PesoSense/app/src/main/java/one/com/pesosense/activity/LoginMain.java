package one.com.pesosense.activity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import one.com.pesosense.R;

/**
 * Created by mobile2 on 7/3/15.
 */
public class LoginMain extends FragmentActivity {

    ImageButton login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_main);

        login = (ImageButton) findViewById(R.id.imagebtn10);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i =new Intent(LoginMain.this, Login.class);
                startActivity(i);

            }
        });



    }








}
